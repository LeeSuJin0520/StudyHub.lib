package com.kh.FinalProject.booksales.model.exception;

public class BSException extends RuntimeException{
	
	public BSException() {}
	public BSException(String message) {
		super(message);
	}
}
