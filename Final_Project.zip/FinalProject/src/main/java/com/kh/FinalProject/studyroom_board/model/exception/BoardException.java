package com.kh.FinalProject.studyroom_board.model.exception;

public class BoardException extends RuntimeException{
	public BoardException() {}
	public BoardException(String message) {
		super(message);
	}

}
