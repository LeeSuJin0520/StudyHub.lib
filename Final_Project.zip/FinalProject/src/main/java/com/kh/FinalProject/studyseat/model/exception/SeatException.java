package com.kh.FinalProject.studyseat.model.exception;

public class SeatException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public SeatException() {
		
	}
	
	public SeatException(String message) {
		super(message);
	}

}
