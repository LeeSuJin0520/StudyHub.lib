package com.kh.FinalProject.notice.model.exception;

public class NoticeException extends RuntimeException{

	public NoticeException() {}
	public NoticeException(String message) {
		super(message);
	}
	
}


